import { test, expect } from "@playwright/test";

test.beforeEach(async ({ page }) => {
  await page.goto("/login");
  await page
    .getByLabel("Email")
    .fill(process.env.INITIAL_ADMIN_EMAIL ?? "admin@towertrack.local");
  await page
    .getByLabel("Password")
    .fill(process.env.INITIAL_ADMIN_PASSWORD ?? "ChangeMe123!");
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page).toHaveURL("/");
});
test("home leads directly into tower event entry", async ({ page }) => {
  await expect(
    page.getByRole("heading", { name: "Action Center" }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Work that can be completed together" }),
  ).toBeVisible();
  await expect(page.getByText("Tower directory")).toHaveCount(0);
  await expect(
    page.getByRole("link", { name: "Planning", exact: true }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("link", { name: "Schedule", exact: true }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("link", { name: "Calendar", exact: true }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("link", { name: "Routes", exact: true }),
  ).toHaveCount(0);
  await expect(page.getByText(/truck rolls?/i)).toHaveCount(0);
  const search = page.getByRole("combobox", { name: "Find a tower" });
  await search.fill("JOB-1002");
  await expect(page.getByRole("option").first()).toBeVisible();
  await page.getByRole("option").first().click();
  await page.getByRole("button", { name: "Add compliance record" }).click();
  await expect(
    page.getByRole("heading", { name: "What happened?" }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Record startup" }),
  ).not.toBeVisible();
  await expect(
    page.getByText("Other work and special conditions", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Inspection" }).click();
  await expect(
    page.getByRole("heading", {
      name: "Record quarterly inspection completed",
    }),
  ).toBeVisible();
  await expect(page.getByRole("button", { name: "Save record" })).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Next required actions" }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Recent activity" }),
  ).toBeVisible();
});
test("system view shows authority and separate target and hard due", async ({
  page,
}) => {
  const search = page.getByRole("combobox", { name: "Find a tower" });
  await search.fill("JOB-1002");
  await expect(
    page
      .getByRole("listbox", { name: "Tower search results" })
      .getByRole("option")
      .first(),
  ).toBeVisible();
  await search.press("Enter");
  await page.getByRole("option").first().click();
  await expect(page).toHaveURL(/\/systems\//);
  await expect(
    page.getByRole("heading", { name: "Next required actions" }),
  ).toBeVisible();
  await expect(
    page.getByText("Recommended service date").first(),
  ).toBeVisible();
  await expect(page.getByText("Compliance deadline").first()).toBeVisible();
  await expect(page.getByText("Next hard due")).toHaveCount(0);
  await page.getByRole("link", { name: "Required work", exact: true }).click();
  await page
    .getByText("Reporting and advanced requirement details", { exact: true })
    .click();
  const whyRequired = page
    .getByText("Why this is required", { exact: true })
    .first();
  const requirement = whyRequired.locator("xpath=ancestor::article[1]");
  await whyRequired.click();
  await expect(requirement.getByText(/^Source:/)).toBeVisible();
});
test("theme toggle replaces the decorative bell and persists the choice", async ({
  page,
}) => {
  const darkMode = page.getByRole("button", { name: "Switch to dark mode" });
  await expect(darkMode).toBeVisible();
  await darkMode.click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  const darkPalette = await page.evaluate(() => {
    const read = (className: string) => {
      const element = document.createElement("div");
      element.className = className;
      document.body.append(element);
      const style = getComputedStyle(element);
      const colors = {
        background: style.backgroundColor,
        border: style.borderTopColor,
        text: style.color,
      };
      element.remove();
      return colors;
    };
    return {
      warning: read("border border-amber-300 bg-amber-50 text-amber-950"),
      information: read("border border-blue-300 bg-blue-50 text-blue-950"),
      danger: read("border border-red-300 bg-red-50 text-red-950"),
      strongText: read("text-slate-950"),
    };
  });
  expect(darkPalette.warning).toEqual({
    background: "rgb(50, 37, 14)",
    border: "rgb(211, 167, 67)",
    text: "rgb(255, 224, 160)",
  });
  expect(darkPalette.information.text).toBe("rgb(197, 231, 255)");
  expect(darkPalette.danger.text).toBe("rgb(255, 196, 200)");
  expect(darkPalette.strongText.text).toBe("rgb(219, 229, 223)");
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await page.getByRole("button", { name: "Switch to light mode" }).click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
});

test("secondary workflow destinations are removed from primary navigation", async ({
  page,
}) => {
  await expect(
    page.getByRole("link", { name: "Corrective Actions" }),
  ).toHaveCount(0);
  await expect(page.getByRole("link", { name: "Review" })).toHaveCount(0);
  await expect(page.getByRole("link", { name: "Customers" })).toBeVisible();
  await expect(page.getByRole("link", { name: "Settings" })).toBeVisible();
  await expect(
    page.getByRole("link", { name: "Overdue & Problems" }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("link", { name: "Towers", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("link", { name: "Samples", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("link", { name: "History", exact: true }),
  ).toBeVisible();

  await page.goto("/work/overdue-towers");
  await expect(
    page.getByRole("heading", { name: "Compliance issues" }),
  ).toBeVisible();
  await expect(
    page.getByRole("navigation", { name: "Tower work categories" }),
  ).toHaveCount(0);

  await page.goto("/work/open-obligations");
  await expect(page).toHaveURL("/deadlines");
  await page.goto("/work/emergency-samples");
  await expect(page).toHaveURL("/");

  await page.goto("/work/compatible-work");
  await expect(
    page.getByRole("heading", { name: "Work that can be completed together" }),
  ).toBeVisible();
  await page.goto("/admin");
  await expect(page.getByRole("heading", { name: "Settings" })).toBeVisible();
});

test("home presents mutually exclusive Action Center sections", async ({
  page,
}) => {
  await expect(page.getByText("Booked field visits")).toHaveCount(0);
  await expect(
    page.getByRole("heading", {
      name: "Due this week",
    }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Work that can be completed together" }),
  ).toBeVisible();
  await expect(page.getByRole("heading", { name: "Next week" })).toBeVisible();
  await expect(
    page.getByText("Deadline", { exact: true }).first(),
  ).toBeVisible();
  await expect(
    page
      .getByText(/Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday/)
      .first(),
  ).toBeVisible();
  await expect(
    page.getByRole("link", { name: /^Overdue towers:/ }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("link", { name: /^Emergency samples/ }),
  ).toHaveCount(0);
  const homeText = await page.locator("main").innerText();
  expect(homeText).not.toContain("Missed or overdue obligations");
  expect(homeText).not.toContain("Recently completed");
  expect(homeText).not.toContain("Annual and recurring requirements");
  await page.getByRole("link", { name: "View all compatible work" }).click();
  await expect(page).toHaveURL("/work/compatible-work");
  await expect(
    page.getByRole("heading", { name: "Work that can be completed together" }),
  ).toBeVisible();
});

test("priority queue remains scannable on a phone-sized screen", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await expect(
    page.getByRole("heading", {
      name: "Due this week",
    }),
  ).toBeVisible();
  const dimensions = await page.evaluate(() => ({
    viewport: document.documentElement.clientWidth,
    content: document.documentElement.scrollWidth,
  }));
  expect(dimensions.content).toBeLessThanOrEqual(dimensions.viewport + 1);
});

test("mobile navigation stays compact and exposes the active destinations", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await expect(
    page.getByRole("navigation", { name: "Primary navigation" }),
  ).toBeHidden();
  await page.locator("aside details summary").click();
  const navigation = page.getByRole("navigation", {
    name: "Mobile navigation",
  });
  await expect(navigation).toBeVisible();
  await expect(
    navigation.getByRole("link", { name: "Action Center", exact: true }),
  ).toHaveAttribute("aria-current", "page");
  await expect(
    navigation.getByRole("link", { name: "All Deadlines" }),
  ).toBeVisible();
});

test("top search finds towers by building and job number", async ({ page }) => {
  const search = page.getByRole("combobox", { name: "Find a tower" });
  await search.fill("100 Park Avenue");
  const result = page
    .getByRole("listbox", { name: "Tower search results" })
    .getByRole("option", { name: /100 Park Avenue — CT-1/ })
    .first();
  await expect(result).toBeVisible();
  await result.click();
  await expect(page).toHaveURL(/\/systems\/[a-z0-9]+$/);
  await expect(
    page.getByRole("heading", { name: /100 Park Avenue/ }),
  ).toBeVisible();

  await page.goto("/");
  await search.fill("JOB-1001");
  await search.press("Enter");
  await page.getByRole("option").first().click();
  await expect(page).toHaveURL(/\/systems\/[a-z0-9]+$/);
});

test("compatible work guides users to record actual work without scheduling", async ({
  page,
}) => {
  await page.goto("/work/compatible-work");
  await expect(page.getByText("Schedule this visit")).toHaveCount(0);
  await expect(page.getByText("Create this visit")).toHaveCount(0);
  const openTower = page.getByRole("link", { name: "Open tower" }).first();
  if (await openTower.isVisible()) {
    await openTower.click();
    await expect(page).toHaveURL(/\/systems\/[a-z0-9]+#record-event$/);
    await expect(
      page.getByRole("heading", { name: "What happened?" }),
    ).toBeVisible();
  } else {
    await expect(
      page.getByRole("heading", { name: "Nothing in this category" }),
    ).toBeVisible();
  }
});

test("admin can view protected versioned rule definitions", async ({
  page,
}) => {
  await page.getByRole("link", { name: "Settings" }).click();
  await expect(page.getByRole("heading", { name: "Settings" })).toBeVisible();
  await expect(page.getByText("Effective start")).toHaveCount(0);
  await expect(page.getByText("Effective end")).toHaveCount(0);
  const nycProfile = page
    .locator("details.panel")
    .filter({ hasText: "NYC Chapter 8 2026 + NYS Part 4" })
    .first();
  await nycProfile.locator(":scope > summary").click();
  await expect(
    nycProfile.getByText("Legionella sample date ranges"),
  ).toBeVisible();
  await expect(nycProfile.getByText("Tower startup")).toBeVisible();
  await expect(
    nycProfile.getByText("Twice-yearly cleaning or inspection"),
  ).toBeVisible();
  await expect(
    nycProfile.getByText("Protected regulatory baseline"),
  ).toBeVisible();
  await expect(
    nycProfile.getByRole("button", { name: "Create editable copy" }),
  ).toBeVisible();
});

test("customer onboarding continues from address to cooling tower details", async ({
  page,
}) => {
  const customerName = `Workflow Test Customer ${Date.now()}`;
  await page.getByRole("link", { name: "Customers" }).click();
  await page
    .locator("summary")
    .filter({ hasText: "Add a new customer" })
    .click();
  const addCustomer = page.locator("form").filter({
    has: page.getByRole("button", {
      name: "Continue to cooling tower details",
    }),
  });
  await addCustomer.getByLabel("Customer name").fill(customerName);
  await addCustomer.getByLabel("Street address").fill("123 Test Avenue");
  await addCustomer.getByLabel("City").fill("New York");
  await addCustomer.getByLabel("State").fill("NY");
  await addCustomer.getByLabel("ZIP code").fill("10001");
  await addCustomer
    .getByRole("button", { name: "Continue to cooling tower details" })
    .click();
  await expect(
    page.getByRole("heading", { name: "Add cooling tower details" }),
  ).toBeVisible();
  await page.getByLabel("Manufacturer (optional)").fill("Test Manufacturer");
  await page.getByLabel("Model number").fill("MODEL-100");
  await page.getByLabel("Serial number").fill("SERIAL-100");
  await page.getByLabel("Tower location").fill("Roof, west side");
  await page.getByLabel("Cooling Tower Tonnage").fill("450");
  await page.getByLabel("Year-round").check();
  await page.getByLabel("Our company manages Legionella").check();
  await page
    .getByLabel(/Tower jurisdiction/)
    .selectOption({ label: "New York, NY" });
  await expect(
    page.getByRole("heading", { name: "New York City regulatory program" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Create cooling tower" }).click();
  await expect(page.getByText("Cooling tower created")).toBeVisible();
  await page.getByRole("link", { name: "Tower Information" }).click();
  await expect(
    page.getByRole("heading", { name: "Equipment details" }),
  ).toBeVisible();
  await expect(page.getByText("MODEL-100")).toBeVisible();
  await expect(page.getByText("SERIAL-100")).toBeVisible();
  await expect(page.getByText("450 tons")).toBeVisible();
  await page
    .getByRole("link", { name: "Edit customer and tower information" })
    .click();
  await expect(
    page.getByRole("heading", { name: new RegExp(`Edit ${customerName}`) }),
  ).toBeVisible();
  await expect(page.getByLabel("Jurisdiction", { exact: true })).toHaveCount(0);
  await page.getByLabel("Tower location").fill("Roof, east side");
  await page
    .getByRole("button", { name: "Save customer and tower changes" })
    .click();
  await expect(
    page.getByText(/customer, address, and tower equipment saved/i),
  ).toBeVisible();
  await page.getByRole("link", { name: "Tower Information" }).click();
  await expect(page.getByText("Roof, east side")).toBeVisible();
});

test("legacy sample correction route opens the audited event editor", async ({
  page,
}) => {
  const search = page.getByRole("combobox", { name: "Find a tower" });
  await search.fill("JOB-1001");
  const result = page
    .getByRole("listbox", { name: "Tower search results" })
    .getByRole("option")
    .first();
  await expect(result).toHaveAttribute("href", /^\/systems\//);
  const systemUrl = await result.getAttribute("href");
  await page.goto(`${systemUrl}/correct`);
  await expect(page).toHaveURL(/\/events\//);
  await expect(
    page.getByRole("heading", {
      name: "The information is wrong—replace it with corrected information",
    }),
  ).toBeVisible();
  await expect(page.getByText("Correction reason (required)")).toBeVisible();
});

test("operations manager can open and correct an individual event", async ({
  page,
}) => {
  const search = page.getByRole("combobox", { name: "Find a tower" });
  await search.fill("JOB-1002");
  await search.press("Enter");
  await page.getByRole("option").first().click();
  await page.getByRole("link", { name: "Records", exact: true }).click();
  const eventHistory = page.locator("#regulatory-events");
  await eventHistory
    .getByRole("link", { name: /View or edit event/ })
    .first()
    .click();
  await expect(
    page.getByRole("heading", {
      name: "The information is wrong—replace it with corrected information",
    }),
  ).toBeVisible();
  await expect(page.getByLabel("Event type")).toBeVisible();
  await expect(page.getByLabel(/date.*Required/)).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Correction impact preview" }),
  ).toBeVisible();
  await page.getByLabel(/date.*Required/).fill("2026-07-17");
  await page
    .getByLabel("Notes")
    .fill("Corrected through event detail workflow");
  await page
    .getByLabel("Correction reason (required)")
    .fill("Verified against the signed field record");
  await page.getByRole("button", { name: "Save corrected record" }).click();
  await expect(page.getByText(/Compliance record corrected/)).toBeVisible();
  await expect(
    page
      .locator("#regulatory-events")
      .getByText("corrected replacement")
      .first(),
  ).toBeVisible();
});

test("operations manager records cleaning in the tower event workflow", async ({
  page,
}) => {
  await page.goto("/");
  const search = page.getByRole("combobox", { name: "Find a tower" });
  await search.fill("Pennsylvania Distribution Hub");
  await page
    .getByRole("listbox", { name: "Tower search results" })
    .getByRole("option", { name: /Pennsylvania Distribution Hub/ })
    .first()
    .click();
  await expect(page).toHaveURL(/\/systems\//);
  await page.getByRole("button", { name: "Add compliance record" }).click();
  await expect(
    page.getByRole("heading", { name: "What happened?" }),
  ).toBeVisible();
  await page
    .getByText("Other work and special conditions", { exact: true })
    .click();
  const addCleaning = page.getByRole("button", { name: "Cleaning" });
  await expect(addCleaning).toBeVisible();
  await addCleaning.click();
  await expect(
    page.getByRole("group", { name: /Cleaning type/ }),
  ).toBeVisible();
  const eventForm = page.locator("#record-event form");
  const completionDate = eventForm.getByLabel(/date.*Required/);
  await expect(completionDate).toBeFocused();
  await expect(completionDate).toHaveValue("");
  await completionDate.fill("2026-07-13");
  await eventForm.getByText("Add notes (optional)", { exact: true }).click();
  await eventForm.getByLabel("Notes").fill("Verified field cleaning record");
  await eventForm.getByRole("button", { name: "Save record" }).click();
  await expect(page).toHaveURL(/event=/);
  await expect(page.getByText(/Event recorded/)).toBeVisible();
  await page.getByRole("link", { name: "Overview", exact: true }).click();
  const recentActivity = page.locator(".panel").filter({
    has: page.getByRole("heading", { name: "Recent activity" }),
  });
  await expect(recentActivity).toBeVisible();
  await expect(recentActivity.getByText("Tue, Jul 14, 2026")).toBeVisible();
});
