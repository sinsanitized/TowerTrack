import { notFound } from "next/navigation";
import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import {
  changeTowerRuleConfigurationAction,
  updateCustomerTowerAction,
  updateServiceResponsibilityAction,
} from "@/app/actions";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { UserRole } from "@prisma/client";
import { towerRuleConfigurationLabel } from "@/lib/tower-rule-configuration";
import { formatDate, todayDateOnly } from "@/lib/date";
import {
  serviceResponsibilityFamilies,
  type TowerServiceResponsibilities,
} from "@/lib/service-responsibility";
import { SubmitButton } from "@/components/submit-button";
import { ServiceResponsibilityFields } from "@/components/service-responsibility-fields";
import { ComplianceRuleProfileFields } from "@/components/compliance-rule-profile-fields";

function jurisdictionLabel(jurisdiction: {
  city: string | null;
  county: string | null;
  municipality: string | null;
  state: string;
}) {
  return [
    jurisdiction.city,
    jurisdiction.county,
    jurisdiction.municipality,
    jurisdiction.state,
  ]
    .filter(Boolean)
    .join(", ");
}

export default async function EditCustomerTowerPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{
    focus?: string;
    returnTo?: string;
    section?: string;
  }>;
}) {
  const user = await requireRole([UserRole.ADMIN, UserRole.OPERATIONS_MANAGER]);
  const { id } = await params;
  const {
    focus,
    returnTo: requestedReturnTo,
    section: requestedSection,
  } = await searchParams;
  const returnTo =
    requestedReturnTo?.startsWith("/") && !requestedReturnTo.startsWith("//")
      ? requestedReturnTo
      : null;
  const focusedResponsibility = serviceResponsibilityFamilies.find(
    ([key]) => key === focus,
  )?.[0];
  const section = focusedResponsibility
    ? "responsibilities"
    : requestedSection === "responsibilities" || requestedSection === "rules"
      ? requestedSection
      : "information";
  const [system, profiles, jurisdictions] = await Promise.all([
    db.coolingTowerSystem.findFirst({
      where: {
        id,
        building: { customer: { organizationId: user.organizationId } },
      },
      include: {
        building: { include: { customer: true } },
        ruleProfile: true,
        ruleAssignments: {
          include: {
            ruleProfile: true,
            changedBy: { select: { name: true } },
          },
          orderBy: { effectiveStartDate: "desc" },
        },
      },
    }),
    db.ruleProfile.findMany({
      where: {
        active: true,
        OR: [{ organizationId: null }, { organizationId: user.organizationId }],
      },
      orderBy: { name: "asc" },
    }),
    db.jurisdiction.findMany({ orderBy: [{ state: "asc" }, { city: "asc" }] }),
  ]);
  if (!system) notFound();
  return (
    <>
      <PageHeader
        eyebrow={
          section === "information"
            ? "Tower information"
            : "Tower configuration"
        }
        title={
          section === "responsibilities"
            ? `Service responsibilities — ${system.systemName}`
            : section === "rules"
              ? `Compliance rules — ${system.systemName}`
              : `Edit ${system.building.customer.name} — ${system.systemName}`
        }
        description={
          section === "responsibilities"
            ? "Confirm who performs each service. These assignments control work queues but do not change legal requirements."
            : section === "rules"
              ? "Change the verified jurisdiction and rule assignment using the effective-dated audited workflow."
              : "Update verified customer, address, and cooling tower equipment information."
        }
        actions={
          <Link className="btn" href={returnTo ?? `/systems/${system.id}`}>
            Cancel
          </Link>
        }
      />
      {section === "information" && (
        <form
          action={updateCustomerTowerAction}
          className="mx-auto max-w-4xl space-y-6"
        >
          <input type="hidden" name="systemId" value={system.id} />
          <p className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-sm font-bold text-blue-950">
            This form saves only customer, address, and tower equipment.
            Configuration changes are managed from Tower Settings.
          </p>
          <section className="panel p-6">
            <div className="label">Customer and address</div>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <label className="sm:col-span-2">
                <span className="label">Customer name</span>
                <input
                  className="field mt-1"
                  name="customerName"
                  defaultValue={system.building.customer.name}
                  required
                />
              </label>
              <label className="sm:col-span-2">
                <span className="label">Street address</span>
                <input
                  className="field mt-1"
                  name="streetAddress"
                  defaultValue={system.building.streetAddress}
                  required
                />
              </label>
              <label>
                <span className="label">Suite / unit (optional)</span>
                <input
                  className="field mt-1"
                  name="addressLine2"
                  defaultValue={system.building.addressLine2 || ""}
                />
              </label>
              <label>
                <span className="label">City</span>
                <input
                  className="field mt-1"
                  name="city"
                  defaultValue={system.building.city}
                  required
                />
              </label>
              <label>
                <span className="label">State</span>
                <input
                  className="field mt-1 uppercase"
                  name="state"
                  maxLength={2}
                  defaultValue={system.building.state}
                  required
                />
              </label>
              <label>
                <span className="label">ZIP code</span>
                <input
                  className="field mt-1"
                  name="postalCode"
                  defaultValue={system.building.postalCode}
                  required
                />
              </label>
            </div>
          </section>
          <section className="panel p-6">
            <div className="label">Cooling tower equipment</div>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <label>
                <span className="label">Tower name</span>
                <input
                  className="field mt-1"
                  name="systemName"
                  defaultValue={system.systemName}
                  required
                />
              </label>
              <label>
                <span className="label">Manufacturer (optional)</span>
                <input
                  className="field mt-1"
                  name="manufacturer"
                  defaultValue={system.manufacturer || ""}
                />
              </label>
              <label>
                <span className="label">Model number</span>
                <input
                  className="field mt-1"
                  name="modelNumber"
                  defaultValue={system.modelNumber || ""}
                />
              </label>
              <label>
                <span className="label">Serial number</span>
                <input
                  className="field mt-1"
                  name="serialNumber"
                  defaultValue={system.serialNumber || ""}
                />
              </label>
              <label>
                <span className="label">Tower location</span>
                <input
                  className="field mt-1"
                  name="towerLocation"
                  defaultValue={system.towerLocation || ""}
                />
              </label>
              <label>
                <span className="label">Cooling tower tonnage</span>
                <input
                  className="field mt-1"
                  name="tonnage"
                  type="number"
                  min="0.1"
                  step="0.1"
                  defaultValue={system.tonnage || ""}
                />
              </label>
            </div>
          </section>
          <section className="panel p-6">
            <label>
              <span className="label">
                Why are you making this change? · Required
              </span>
              <input
                className="field mt-1"
                name="reason"
                aria-label="Reason for changes"
                minLength={8}
                placeholder="Example: Corrected the serial number from the equipment plate"
                required
              />
            </label>
            <SubmitButton
              className="mt-4 w-full"
              pendingLabel="Saving customer and tower changes…"
            >
              Save customer and tower changes
            </SubmitButton>
          </section>
        </form>
      )}
      {section === "responsibilities" && (
        <section
          id="service-responsibilities"
          className="panel mx-auto max-w-4xl scroll-mt-6 p-6"
        >
          <div className="label">Service responsibilities</div>
          <h2 className="mt-1 text-xl font-black">
            Who is responsible for each service
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            This controls operational ownership only. It does not change the
            legal requirements assigned to this tower. This section is saved
            separately.
          </p>
          {focusedResponsibility && (
            <div className="mt-4 rounded-lg border border-blue-200 bg-blue-50 p-3 text-sm font-bold text-blue-900">
              Assign the highlighted service responsibility, then save this
              section.
            </div>
          )}
          {serviceResponsibilityFamilies.some(
            ([key]) => system[key] == null,
          ) && (
            <div className="mt-4 rounded-lg border border-purple-300 bg-purple-50 p-3 text-sm font-bold text-purple-900">
              One or more service responsibilities must be confirmed. Unknown
              work remains visible until ownership is assigned.
            </div>
          )}
          <form
            action={updateServiceResponsibilityAction}
            className="mt-4 grid gap-4 sm:grid-cols-2"
          >
            <input type="hidden" name="systemId" value={system.id} />
            {returnTo && (
              <input type="hidden" name="returnTo" value={returnTo} />
            )}
            <ServiceResponsibilityFields
              responsibilities={system as TowerServiceResponsibilities}
              focusedResponsibility={focusedResponsibility}
              legionellaVendorName={system.legionellaVendorName}
            />
            <label className="sm:col-span-2">
              <span className="label">
                Why are you changing responsibility? · Required
              </span>
              <input
                className="field mt-1"
                name="reason"
                aria-label="Reason"
                placeholder="Example: Confirmed the service contract with the customer"
                minLength={8}
                required
              />
            </label>
            <SubmitButton
              className="sm:col-span-2"
              pendingLabel="Saving service responsibilities…"
            >
              Save service responsibilities
            </SubmitButton>
          </form>
        </section>
      )}
      {section === "rules" && (
        <section className="panel mx-auto max-w-4xl p-6">
          <div className="label">Compliance rules</div>
          <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
            <div>
              <h2 className="text-xl font-black">
                {towerRuleConfigurationLabel(system.ruleConfiguration)}
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                {system.ruleProfile.name} · Effective{" "}
                {formatDate(system.ruleConfigurationEffectiveDate)}
              </p>
            </div>
            {!system.ruleConfigurationConfirmed && (
              <div className="rounded-lg bg-purple-100 px-3 py-2 text-sm font-black text-purple-900">
                Compliance rules must be confirmed.
              </div>
            )}
          </div>
          <details className="mt-5 rounded-xl border border-slate-200 p-4">
            <summary className="cursor-pointer font-black text-emerald-900">
              Change compliance rules
            </summary>
            <form
              action={changeTowerRuleConfigurationAction}
              className="mt-4 grid gap-4 sm:grid-cols-2"
            >
              <input type="hidden" name="systemId" value={system.id} />
              <ComplianceRuleProfileFields
                profiles={profiles}
                jurisdictions={jurisdictions.map((jurisdiction) => ({
                  id: jurisdiction.id,
                  label: jurisdictionLabel(jurisdiction),
                  state: jurisdiction.state,
                  city: jurisdiction.city,
                }))}
                initialConfiguration={system.ruleConfiguration}
                initialProfileId={system.ruleProfileId}
                initialJurisdictionId={system.jurisdictionId}
              />
              <label>
                <span className="label">Effective date</span>
                <input
                  className="field mt-1"
                  name="effectiveDate"
                  type="date"
                  min={todayDateOnly()}
                  max={todayDateOnly()}
                  defaultValue={todayDateOnly()}
                  required
                />
                <span className="mt-1 block text-xs text-slate-600">
                  Enter the date as month, day, and year.
                </span>
              </label>
              <label>
                <span className="label">
                  Why are you changing these rules? · Required
                </span>
                <input
                  className="field mt-1"
                  name="reason"
                  aria-label="Reason"
                  minLength={8}
                  placeholder="Example: Verified the applicable jurisdiction with the owner"
                  required
                />
              </label>
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-950 sm:col-span-2">
                <div className="font-black">Compliance impact preview</div>
                <ul className="mt-2 list-disc space-y-1 pl-5">
                  <li>
                    The current assignment will end the day before the effective
                    date.
                  </li>
                  <li>
                    Open requirements will be recalculated under the selected
                    jurisdiction and profile.
                  </li>
                  <li>
                    Historical events and prior effective-dated assignments
                    remain unchanged.
                  </li>
                </ul>
                <label className="mt-3 flex items-start gap-2 font-bold">
                  <input
                    name="impactConfirmed"
                    type="checkbox"
                    value="yes"
                    required
                  />
                  I reviewed the jurisdiction, effective date, and recalculation
                  impact.
                </label>
              </div>
              <SubmitButton
                className="sm:col-span-2"
                pendingLabel="Changing compliance rules…"
              >
                Change compliance rules
              </SubmitButton>
            </form>
          </details>
          <details className="mt-4 text-sm">
            <summary className="cursor-pointer font-bold text-emerald-900">
              Assignment history
            </summary>
            <div className="mt-3 space-y-3">
              {system.ruleAssignments.map((assignment) => (
                <div key={assignment.id} className="rounded-lg bg-slate-50 p-3">
                  <div className="font-black">
                    {towerRuleConfigurationLabel(assignment.configuration)}
                  </div>
                  <div className="text-slate-600">
                    {assignment.ruleProfile.name} ·{" "}
                    {formatDate(assignment.effectiveStartDate)}
                    {assignment.effectiveEndDate
                      ? ` through ${formatDate(assignment.effectiveEndDate)}`
                      : " onward"}
                  </div>
                  <div className="mt-1 text-xs text-slate-500">
                    {assignment.changedBy?.name ??
                      "Imported historical assignment"}{" "}
                    · {assignment.reason}
                  </div>
                </div>
              ))}
            </div>
          </details>
        </section>
      )}
    </>
  );
}
